﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Encodings.Web;

namespace IceTaskOne.Controllers
{
    public class ContentDisplayer : Controller
    {
        public IActionResult TheVoid()
        {
            return View();
        }
    }
}
