﻿namespace IceTaskOne.Models
{
    public class People
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int MemberLength { get; set; }
    }
}
